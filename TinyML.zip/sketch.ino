#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ArduTFLite.h>
#include "model.h"

// ==============================
// LDR
// ==============================

#define LDR_PIN 34

// ==============================
// OLED
// ==============================

#define OLED_SDA 21
#define OLED_SCL 22

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

// ==============================
// TinyML
// ==============================

constexpr int TENSOR_ARENA_SIZE = 64 * 1024;

alignas(16) uint8_t tensorArena[TENSOR_ARENA_SIZE];


// ==============================
// SETUP
// ==============================

void setup()
{
  Serial.begin(115200);
  delay(2000);

  Serial.println();
  Serial.println("==============================");
  Serial.println("SMART LIGHT TINYML");
  Serial.println("==============================");

  // LDR
  pinMode(LDR_PIN, INPUT);
  analogReadResolution(12);

  // OLED
  Wire.begin(OLED_SDA, OLED_SCL);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println("OLED INITIALIZATION FAILED!");
    
    while (true)
    {
      delay(1000);
    }
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  display.setCursor(0, 0);
  display.println("SMART LIGHT");
  display.println("TINYML");
  display.println();
  display.println("Loading...");

  display.display();

  delay(1000);

  // ==============================
  // TinyML MODEL
  // ==============================

  Serial.print("Model size: ");
  Serial.println(model_len);

  Serial.println("Initializing TinyML model...");

  bool success = modelInit(
    model,
    tensorArena,
    TENSOR_ARENA_SIZE
  );

  if (!success)
  {
    Serial.println("MODEL INIT FAILED!");

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("TINYML ERROR");
    display.println();
    display.println("MODEL INIT FAILED");
    display.display();

    while (true)
    {
      delay(1000);
    }
  }

  Serial.println("MODEL INIT SUCCESS!");

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("TINYML READY");
  display.println();
  display.println("LDR CLASSIFIER");
  display.display();

  delay(1500);
}


// ==============================
// LOOP
// ==============================

void loop()
{
  // Read LDR
  int ldrValue = analogRead(LDR_PIN);

  // Normalize
  float inputValue = (float)ldrValue / 4095.0f;

  // ==============================
  // MODEL INPUT
  // ==============================

  if (!modelSetInput(inputValue, 0))
  {
    Serial.println("INPUT SET FAILED!");
    delay(1000);
    return;
  }

  // ==============================
  // RUN INFERENCE
  // ==============================

  if (!modelRunInference())
  {
    Serial.println("INFERENCE FAILED!");
    delay(1000);
    return;
  }

  // ==============================
  // MODEL OUTPUT
  // ==============================

  float darkOutput = modelGetOutput(0);
  float normalOutput = modelGetOutput(1);
  float brightOutput = modelGetOutput(2);

  // ==============================
  // CLASSIFICATION
  // ==============================

  String lightClass;
  float confidence;

  if (darkOutput >= normalOutput &&
      darkOutput >= brightOutput)
  {
    lightClass = "DARK";
    confidence = darkOutput;
  }
  else if (normalOutput >= darkOutput &&
           normalOutput >= brightOutput)
  {
    lightClass = "NORMAL";
    confidence = normalOutput;
  }
  else
  {
    lightClass = "BRIGHT";
    confidence = brightOutput;
  }

  // ==============================
  // SERIAL MONITOR
  // ==============================

  Serial.println("------------------------------");

  Serial.print("LDR Value : ");
  Serial.println(ldrValue);

  Serial.print("Input     : ");
  Serial.println(inputValue, 4);

  Serial.print("DARK      : ");
  Serial.println(darkOutput, 4);

  Serial.print("NORMAL    : ");
  Serial.println(normalOutput, 4);

  Serial.print("BRIGHT    : ");
  Serial.println(brightOutput, 4);

  Serial.print("CLASS     : ");
  Serial.println(lightClass);

  Serial.print("CONFIDENCE: ");
  Serial.println(confidence, 4);

  // ==============================
  // OLED
  // ==============================

  display.clearDisplay();

  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  display.setCursor(0, 0);
  display.println("SMART LIGHT");

  display.setCursor(0, 15);
  display.print("LDR: ");
  display.println(ldrValue);

  display.setCursor(0, 30);
  display.print("CLASS: ");
  display.println(lightClass);

  display.setCursor(0, 45);
  display.print("CONF: ");
  display.println(confidence, 2);

  display.display();

  delay(1000);
}